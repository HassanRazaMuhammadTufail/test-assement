const messages = {
  API_SUCCESSS: 'Success',
};
export default messages;
